#include "DXApp.h"

void DXApp::Init()
{
}

void DXApp::Update()
{
}

void DXApp::Finalize()
{
}

void DXApp::OnPause()
{
}
